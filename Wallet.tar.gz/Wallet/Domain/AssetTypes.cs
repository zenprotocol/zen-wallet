﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Wallet
{
	public class AssetTypes : Dictionary<String, AssetType>
	{
	}
}

