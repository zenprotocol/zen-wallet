﻿using System;

namespace Wallet
{
	public enum DirectionEnum {
		Sent, Recieved
	}
}

