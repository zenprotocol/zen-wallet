﻿//using System;
//
//namespace Wallet
//{
//	public enum CurrencyEnum {
//		Bitcoin, Ether, Zen, Lite
//	}
//}
//
