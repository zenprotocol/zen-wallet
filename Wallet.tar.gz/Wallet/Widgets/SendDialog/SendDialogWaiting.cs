﻿using System;

namespace Wallet
{
	[System.ComponentModel.ToolboxItem (true)]
	public partial class SendDialogWaiting : Gtk.Bin
	{
		public SendDialogWaiting ()
		{
			this.Build ();
		}
	}
}

