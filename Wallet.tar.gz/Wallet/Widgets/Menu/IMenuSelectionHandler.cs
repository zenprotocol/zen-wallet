﻿using System;

namespace Wallet
{
	public interface IMenu {
		int Default { set; }
	}
}

