﻿using System;
using Gtk;

namespace Wallet
{
	[System.ComponentModel.ToolboxItem (true)]
	public partial class TextButton : WidgetBase
	{
		public TextButton ()
		{
		//	this.Build ();
		}

		public String Text {
			set {
		//		label.Text = value;
			}
		}
	}
}

