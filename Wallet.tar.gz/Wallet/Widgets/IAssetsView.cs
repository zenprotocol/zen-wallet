﻿//using System;
//using System.Collections.Generic;
//
//namespace Wallet
//{
//	public interface IAssetsView
//	{
//		AssetTypes Assets { set; }
//	}
//}
//
