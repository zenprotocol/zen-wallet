﻿using System;

namespace Wallet
{
	public abstract class FocusableWidget : WidgetBase
	{
		public abstract void Focus();
	}
}

