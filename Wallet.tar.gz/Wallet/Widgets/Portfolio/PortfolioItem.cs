﻿using System;

namespace Wallet
{
	[System.ComponentModel.ToolboxItem (true)]
	public partial class PortfolioItem : Gtk.Bin
	{
		public PortfolioItem ()
		{
			this.Build ();
		}
	}
}

